/*
 * * First C program that says "Hello world!" 
 * * Hello.c
 * */

#include <stdio.h>  // Needed to perform IO operations

int main() {                    // Program entry point
   printf("Hello world!\n");   // Says what is bewteen ""
   return 0;                    // Terminate main()
}                               // End of main()
