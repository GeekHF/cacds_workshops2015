/*
 * CACDS HPC bootcamp
 * template1.c
 */

#include <stdio.h>  // Needed to perform IO operations

int main() {                    // Program entry point
   printf("Hello world!\n");   // Says what is bewteen ""

   return 0;                    // Terminate main()
}                               // End of main()

