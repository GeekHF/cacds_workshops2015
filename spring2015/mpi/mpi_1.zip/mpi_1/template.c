/*--Include standard I/O C header file */
#include <stdio.h>

/*--Include the MPI header file */
#include "mpi.h"

/*--Template for MPI Programs in C */

int main( int argc, char* argv[])
{
/*--Declare all variables and arrays. */
      int myid,numprocs,itag;


      MPI_Init(&argc,&argv);        /* --> Required statement */

/*--Who am I? --- get my rank=myid */
      MPI_Comm_rank(MPI_COMM_WORLD,&myid);

/*--How many processes in the global group? */
      MPI_Comm_size(MPI_COMM_WORLD,&numprocs);

/*--Finilize MPI */
      MPI_Finalize();              /* ---> Required statement */

      return 0;
} 

