/*--Include standard C I/O header file */
#include <stdio.h>

/*--Include MPI header file */
#include "mpi.h"

/*--All processes send a message to process 0 */
int main(int argc,char *argv[])
{

      int i,myid,numprocs;
      int message,mess_received,iroot_pe,itag,icount;
      MPI_Status status;

/*--Initialize MPI */
      MPI_Init(&argc,&argv );

/*--Who am I? --- get my rank=myid */
      MPI_Comm_rank(MPI_COMM_WORLD, &myid);

/*--How many processes in the global group? */
      MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
      printf("Process %d of %d is alive\n",myid,numprocs);

/*--Compose the message */
      message=myid;

/*--Send a message to process 0 */
        icount=1;
        iroot_pe=0;
      if(myid != 0){
        itag=myid;
         MPI_Send(&message,icount,MPI_INT,iroot_pe,itag,
         MPI_COMM_WORLD);
      }else{
        for (i=1;i<=numprocs-1;i++){
         itag=i;
         MPI_Recv(&mess_received,icount,MPI_INT,i,
          itag,MPI_COMM_WORLD, &status);
         printf( "received message from process %d\n",mess_received);
        }        
      }

/*--Finilize MPI */
      MPI_Finalize();

      return 0;
}


