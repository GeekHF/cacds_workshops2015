/* --Include the standard C++ I/O header file */
#include <iostream>

/* --Include the mpi header file */
#include <mpi.h>
using namespace std;
int main(int argc, char* argv[]) 
{
      int myid,numprocs;

/*--Initialize MPI*/
      MPI_Init(&argc, &argv);

/*--Who am I? --- get my rank=myid */
       MPI_Comm_rank( MPI_COMM_WORLD, &myid );

/*--How many processes in the global group? */
      MPI_Comm_size( MPI_COMM_WORLD, &numprocs);
      cout << "I am process  "<< myid <<" of "  << numprocs  <<" MPI processes\n";

/*--Finalize MPI */
      MPI_Finalize();

      return 0;

}
