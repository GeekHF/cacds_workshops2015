/*--Include standard I/O C header file */
#include <stdio.h>

/*--Include the MPI header file */
#include "mpi.h"

int main( int argc, char* argv[])
{



/*--Declare all variables and arrays. */
      int myid,numprocs,itag;
      int ip;
      float x,y;

/*--Initialize MPI */
      MPI_Init(&argc,&argv);        /* --> Required statement */

/*--Who am I? --- get my rank=myid */
      MPI_Comm_rank(MPI_COMM_WORLD,&myid);

/*--How many processes in the global group? */
      MPI_Comm_size(MPI_COMM_WORLD,&numprocs);

/*--Set the value of x on all processes */
      x=5.;

/*--Define the value of y on each process and print it. */
       if(myid == 0) {
        y=x*x;
        printf("On process %d y=%.1f\n",myid,y);
       }else if (myid == 1)  {
        y=x*x*x;
        printf("On process %d y=%.1f\n",myid,y);
       }else if (myid == 2) {
        y=x*x*x*x;
        printf("On process %d y=%.1f\n",myid,y);
       }

/*--Finilize MPI */
       MPI_Finalize();       /* ---> Required statement */

      return 0;
}                            /* END MAIN */      


