%% Script to generate a surface plot
%
  xx = x(1:param.nodesx, 1);
  yy = x(1:param.nodesx:param.nodesx*param.nodesy, 2);

  figure
  surf(xx, yy, reshape(z_ss, param.nodesx, param.nodesy)' );
  xlabel('\bf x');
  ylabel('\bf y');
  zlabel('\bf T')
