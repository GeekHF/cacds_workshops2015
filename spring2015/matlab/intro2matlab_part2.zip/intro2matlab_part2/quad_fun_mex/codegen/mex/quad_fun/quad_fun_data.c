/*
 * quad_fun_data.c
 *
 * Code generation for function 'quad_fun_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "quad_fun.h"
#include "quad_fun_data.h"

/* Variable Definitions */
const volatile char_T *emlrtBreakCheckR2012bFlagVar;

/* End of code generation (quad_fun_data.c) */
