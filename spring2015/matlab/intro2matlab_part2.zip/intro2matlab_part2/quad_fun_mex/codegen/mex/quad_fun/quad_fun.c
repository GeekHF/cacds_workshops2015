/*
 * quad_fun.c
 *
 * Code generation for function 'quad_fun'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "quad_fun.h"
#include "quad_fun_data.h"

/* Variable Definitions */
static emlrtRTEInfo emlrtRTEI = { 5, 2, "quad_fun",
  "C:\\Users\\Amit\\Dropbox\\university of houston\\training\\matlab\\quad_fun.m"
};

/* Function Definitions */
real_T quad_fun(const emlrtStack *sp, real_T n, real_T a, real_T b)
{
  real_T q;
  real_T w;
  int32_T i;
  real_T x;
  q = 0.0;
  w = (b - a) / n;
  emlrtForLoopVectorCheckR2012b(1.0, 1.0, n, mxDOUBLE_CLASS, (int32_T)n,
    &emlrtRTEI, sp);
  i = 0;
  while (i <= (int32_T)n - 1) {
    x = ((n - (1.0 + (real_T)i)) * a + ((1.0 + (real_T)i) - 1.0) * b) / (n - 1.0);
    q += w * (4.0 / (1.0 + x * x));
    i++;
    emlrtBreakCheckFastR2012b(emlrtBreakCheckR2012bFlagVar, sp);
  }

  return q;
}

/* End of code generation (quad_fun.c) */
