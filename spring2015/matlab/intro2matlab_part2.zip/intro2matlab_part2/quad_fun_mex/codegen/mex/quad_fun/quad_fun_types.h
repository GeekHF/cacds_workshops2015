/*
 * quad_fun_types.h
 *
 * Code generation for function 'quad_fun'
 *
 */

#ifndef __QUAD_FUN_TYPES_H__
#define __QUAD_FUN_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* End of code generation (quad_fun_types.h) */
