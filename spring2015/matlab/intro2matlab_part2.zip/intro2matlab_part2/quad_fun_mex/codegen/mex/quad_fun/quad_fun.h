/*
 * quad_fun.h
 *
 * Code generation for function 'quad_fun'
 *
 */

#ifndef __QUAD_FUN_H__
#define __QUAD_FUN_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "quad_fun_types.h"

/* Function Declarations */
extern real_T quad_fun(const emlrtStack *sp, real_T n, real_T a, real_T b);

#ifdef __WATCOMC__

#pragma aux quad_fun value [8087];

#endif
#endif

/* End of code generation (quad_fun.h) */
