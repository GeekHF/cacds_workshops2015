/* 
 * File: quad_fun_types.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 25-Apr-2015 19:56:21 
 */

#ifndef __QUAD_FUN_TYPES_H__
#define __QUAD_FUN_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* 
 * File trailer for quad_fun_types.h 
 *  
 * [EOF] 
 */
