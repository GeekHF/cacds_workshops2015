/* 
 * File: _coder_quad_fun_api.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 25-Apr-2015 19:56:21 
 */

#ifndef ___CODER_QUAD_FUN_API_H__
#define ___CODER_QUAD_FUN_API_H__
/* Include files */
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"

/* Function Declarations */
extern void quad_fun_initialize(emlrtContext *aContext);
extern void quad_fun_terminate(void);
extern void quad_fun_atexit(void);
extern void quad_fun_api(const mxArray * const prhs[3], const mxArray *plhs[1]);
extern double quad_fun(double n, double a, double b);
extern void quad_fun_xil_terminate(void);

#endif
/* 
 * File trailer for _coder_quad_fun_api.h 
 *  
 * [EOF] 
 */
