/*
 * File: quad_fun_terminate.h
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 25-Apr-2015 19:56:21
 */

#ifndef __QUAD_FUN_TERMINATE_H__
#define __QUAD_FUN_TERMINATE_H__

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "quad_fun_types.h"

/* Function Declarations */
extern void quad_fun_terminate(void);

#endif

/*
 * File trailer for quad_fun_terminate.h
 *
 * [EOF]
 */
