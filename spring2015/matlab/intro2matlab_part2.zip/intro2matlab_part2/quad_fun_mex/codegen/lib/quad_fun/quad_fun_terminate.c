/*
 * File: quad_fun_terminate.c
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 25-Apr-2015 19:56:21
 */

/* Include files */
#include "rt_nonfinite.h"
#include "quad_fun.h"
#include "quad_fun_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void quad_fun_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for quad_fun_terminate.c
 *
 * [EOF]
 */
