/* 
 * File: _coder_quad_fun_info.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 25-Apr-2015 19:56:21 
 */

#ifndef ___CODER_QUAD_FUN_INFO_H__
#define ___CODER_QUAD_FUN_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_quad_fun_info.h 
 *  
 * [EOF] 
 */
