/*
 * File: quad_fun.c
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 25-Apr-2015 19:56:21
 */

/* Include files */
#include "rt_nonfinite.h"
#include "quad_fun.h"

/* Function Definitions */

/*
 * Arguments    : double n
 *                double a
 *                double b
 * Return Type  : double
 */
double quad_fun(double n, double a, double b)
{
  double q;
  double w;
  int i;
  double x;
  q = 0.0;
  w = (b - a) / n;
  for (i = 0; i < (int)n; i++) {
    x = ((n - (1.0 + (double)i)) * a + ((1.0 + (double)i) - 1.0) * b) / (n - 1.0);
    q += w * (4.0 / (1.0 + x * x));
  }

  return q;
}

/*
 * File trailer for quad_fun.c
 *
 * [EOF]
 */
