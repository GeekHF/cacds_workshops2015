tic; c=quad_fun(10000000,1,5); toc;
tic; c=quad_fun_mex(10000000,1,5); toc;