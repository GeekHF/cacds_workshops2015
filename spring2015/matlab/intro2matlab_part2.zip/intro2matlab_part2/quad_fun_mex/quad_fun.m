function q = quad_fun (n,a,b)
%#codegen
    q=0.0;
	w=(b-a)/n;
	for i =1:n
		x = ((n-i )*a+(i-1)*b)/(n-1);
		fx= 4./(1+x .^2);
		q = q+w*fx ;
	end
	return
end