%% MD_POOL uses the MATLABPOOL command to run the MD code.
%
%  Discussion:
%
%    Output printed by the function appears directly on the screen.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    26 March 2010
%    16 October 2014 (E.M. Cliff)
%  Author:
%
%    John Burkardt
%
pool_obj = parpool('local', 4);

  [ pe, ke, e_lost ] = md_parfor ( );

delete(pool_obj)
