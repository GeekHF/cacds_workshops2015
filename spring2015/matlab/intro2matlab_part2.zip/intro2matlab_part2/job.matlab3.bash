#!/bin/bash
#PBS -N matlabjob3
#PBS -o matlabjob3.o%j
#PBS -l nodes=1:ppn=1,pmem=1gb
#PBS -S /bin/bash
#PBS -l walltime=00:05:00

cd $PBS_O_WORKDIR


##set up your environment
module add matlab



date

matlab << EOF       

problem
exit 
EOF                                            

