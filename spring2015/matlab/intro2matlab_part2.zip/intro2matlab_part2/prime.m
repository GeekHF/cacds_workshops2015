function total = prime ( n )
%% PRIME returns the number of primes between 1 and N.
	total = 0 ;
	for i = 2 : n
		prime = 1 ;
		for j = 2 : i-1
			if ( mod ( i , j ) == 0 )
			prime = 0 ;
			end
		end
		total = total + prime ;
	end
	return
    end