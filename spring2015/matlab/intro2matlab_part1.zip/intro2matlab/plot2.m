N = 1000;
t = [1:N]/N;
f = sin(2*pi*t);

plot(t,f);
title('The Sine Function'); xlabel('t', 'FontSize',14);
ylabel('sin(2 pi t)','FontSize',14);