function bool=isprime1(n)
bool=1;
for i=2:floor(sqrt(n))
	if mod(n,i)==0
		bool=0; break;
	end
end

