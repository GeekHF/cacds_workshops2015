[X,Y] = meshgrid(-2:.2:2, -2:.2:2);
Z = X .* exp(-X.^2 - Y.^2);
surf(X,Y,Z)
xlabel ('X','Fontsize',18)
ylabel ('Y','Fontsize',18)
zlabel ('Z','Fontsize',18)
title ('3D X,Y,Z Plot of Z = X .* exp(-X.^2 - Y.^2)','Fontsize',18)