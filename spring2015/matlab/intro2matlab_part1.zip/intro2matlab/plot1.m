N = 1000;
f = zeros(N+1,1);
t = zeros(N+1,1);
for i = 1:N
	t(i) = (i-1)/N;
	f(i) = sin(2*pi*t(i));
end
plot(t,f);
title('The Sine Function'); xlabel('t', 'FontSize',14);
ylabel('sin(2 pi t)','FontSize',14);