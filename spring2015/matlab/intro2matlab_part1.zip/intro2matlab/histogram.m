dat = randn(10000, 1);

hist(dat)

hist(dat, 50)

b = hist(dat, 6)

bar(b)
