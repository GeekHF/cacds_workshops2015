/* --Include the standard C I/O header file */
#include <stdio.h>

/* --Include the mpi header file */
#include "mpi.h"

     int main(int argc, char*argv[])
{


/*-- Process 0 sends an array of 5 real variables: x(1:5), to process 1.
   Process 1 prints the values of the received array: y(1:5). */


      int i,numprocs;
      MPI_Status status;
      int dest;
      int my_rank,source;
      float x[5],y[5];
 
/* --the common calling arguments */
      int count   =5;  
      MPI_Datatype datatype=MPI_FLOAT;
      int tag     = 2;
      int comm    = MPI_COMM_WORLD;


/*--Initialize MPI */
       MPI_Init( &argc, &argv);

/*--Who am I? --- get my rank=my_rank */
      MPI_Comm_rank( MPI_COMM_WORLD, &my_rank );

/*--How many processes in the global group? */
      MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
      printf( "Process %d of %d, is alive\n", my_rank,numprocs);

/*---process 0 send data to process 1 (dest=1) */
      if (my_rank == 0){ 
      for (i=1;i<=5; i++){
       x[i-1]=(float)i;
      }
      dest    = 1;
      MPI_Send(&x[0],count,datatype,
              dest,tag,comm);
      }
          
/*---process 1 receives data from process 0 (source=0) */
      if (my_rank == 1) {
     /* float y=0.; */
        int source=0;
        MPI_Recv(&y[0],count,datatype,
                  source,tag,comm,&status);
     printf("At process %d y= %.1f %.1f %.1f %.1f %.1f \n", my_rank,y[0],
            y[1],y[2],y[3],y[4]);
      }

/*--Finilize MPI */
      MPI_Finalize();

      return 0;
     }


