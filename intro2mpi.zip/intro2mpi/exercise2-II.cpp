/*--Include standard I/O C header file */
#include <iostream>

/*--Include C Math Header File */
#include <cmath>

/*--Include the MPI header file */
#include <mpi.h>
using namespace std;

int main( int argc, char* argv[])
{



/*--Declare all variables and arrays. */
      int myid,numprocs,itag;
      int i,ip;
      float x,y;

/*--Initialize MPI */
      MPI_Init(&argc,&argv);        /* --> Required statement */

/*--Who am I? --- get my rank=myid */
      MPI_Comm_rank(MPI_COMM_WORLD,&myid);

/*--How many processes in the global group? */
      MPI_Comm_size(MPI_COMM_WORLD,&numprocs);

/*--Set the value of x on all processes */
      x=5.;

/*--Define the value of y on each process and print it. */
       /* y=x^(2+myid) */
        y=pow(x,2+myid);
        cout << "On process ";
        cout <<myid<<" y = " <<y<< endl;
/*--Finilize MPI */
      MPI_Finalize();              /* ---> Required statement */

      return 0;
}                                  /* END OF MAIN */


