/* Include the standard I/O C header file */
#include <stdio.h>

/* Include the MPI header file */
#include "mpi.h"

int main(int argc, char* argv[])
{

/*---Testing wether messages are buffered on the current platform. */
/*  (if messages are NOT buffered this program will deadlock) */


      int myid,numprocs;
      int tag1,tag2;
      MPI_Status status;
      float a,b;

/*--Initialize MPI */
       MPI_Init(&argc,&argv);

/*--Who am I? --- get my rank=myid */
       MPI_Comm_rank( MPI_COMM_WORLD,&myid);

/*--How many processes in the global group? */
       MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
      printf("Process %d of %d is alive\n",myid,numprocs);

      a=0.;
      b=0.;
      if (myid == 0) {
       a=5.;
      }else if (myid == 2){
       b=10.;
      }

      tag1=1;
      tag2=2;

/*--Exchange messages */
       if (myid == 0) {
         MPI_Sendrecv(&a,1,MPI_FLOAT,1,tag1,
                         &b,1,MPI_FLOAT,2,tag2,
                         MPI_COMM_WORLD,&status);
       } else if (myid==1){
             MPI_Recv(&a,1,MPI_FLOAT,0,tag1,
                         MPI_COMM_WORLD,&status);
       } else if (myid==2) {
             MPI_Send(&b,1,MPI_FLOAT,0,tag2,
                         MPI_COMM_WORLD);
       }

/*--Write out the values of a and b at each process */
       printf("At Process %d a=%.1f  b=%.1f\n",myid,a,b);
/*--Finilize MPI */
      MPI_Finalize();

      return 0;
}                    /* END of MAIN*/

