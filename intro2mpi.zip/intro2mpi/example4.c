/* --Include the Standard I/O C header file */
#include <stdio.h>

/* --Include the MPI header file */
#include "mpi.h"

/* ---Testing wether messages are buffered on the current platform.*/
/*  (if messages are NOT buffered this program will deadlock)*/

int main(int argc, char *argv[])
{
      int myid,numprocs;
      int tag1,tag2;
      MPI_Status status;
      float a,b;

/* --Initialize MPI*/
      MPI_Init(&argc,&argv );

/* --Who am I? --- get my rank=myid*/
      MPI_Comm_rank(MPI_COMM_WORLD,&myid);

/* --How many processes in the global group?*/
      MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
      printf ("Process %d of %d is alive\n",myid,numprocs);

      if (myid == 0) {
       a=0.;
       b=1.;
      }else{
       a=1.;
       b=0.;
      }

/* --Exchange messages*/
      tag1=1;
      tag2=2;
      if (myid == 0) {
       MPI_Sendrecv(&a,1,MPI_FLOAT,1,tag1,
                       &b,1,MPI_FLOAT,1,tag2,
                        MPI_COMM_WORLD,&status);
      }else if (myid == 1) {
       MPI_Sendrecv(&b,1,MPI_FLOAT,0,tag2,
                       &a,1,MPI_FLOAT,0,tag1,
                        MPI_COMM_WORLD,&status);
      }

       printf("myid= %d a= %d b= %d\n",myid,a,b);
/* --Finilize MPI*/
      MPI_Finalize();

      return 0;
}


