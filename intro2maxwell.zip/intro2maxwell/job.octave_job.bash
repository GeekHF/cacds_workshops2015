#!/bin/bash
#PBS -N matlabjob
#PBS -l nodes=1:ppn=1,pmem=1gb
#PBS -S /bin/bash
#PBS -l walltime=00:05:00

cd $PBS_O_WORKDIR

##set up your environment 
module add intel  octave/3.2.4-intel

## run octave program to compute psuedinverse for 100 400x400 matrices

export OMP_NUM_THREADS=1

octave -q  <   matrix_inversion100_octave.m
