#!/bin/bash 
#PBS -l nodes=4:ppn=8
#PBS -l walltime=00:20:00
#PBS -l pmem=1gb
#PBS -N gethostname
#PBS -o gethostname.o%j
#PBS -V

### Run gethostname 
cd $PBS_O_WORKDIR

./gethostname.exe

### Run gethostname
