#include <mpi.h>
main(int argc, char *argv[])
{
  MPI_Init(&argc, &argv );
  // put program here
  MPI_Finalize();
}
