#!/bin/bash 
#PBS -q gpu
#PBS -N jvector_Add
#PBS -o jvector_Add.o%j
#PBS -V
#PBS -l walltime=00:05:00,nodes=1:ppn=1 
#PBS -M monkeybrain@gmail.com 

cd $PBS_O_WORKDIR
##set up your environment 
module add cuda
time    ./vector_add


