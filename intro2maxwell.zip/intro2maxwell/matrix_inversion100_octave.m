%a short demo follows (pseudoinversion of 100 400x400 matrices): 

n = 400; 
m = 100; 
disp ("create 100 random 400x400 matrices"); 
a = rand (n, n, m); 
a = mat2cell (a, n, n, ones (1, m)); 
a = a(:); 
disp ("calculate pseudoinverses - uniprocess"); 
tic; 
p = cellfun (@pinv, a, "UniformOutput", false); 
toc 
clear p 
disp ("calculate pseudoinverses - multiprocess"); 
tic; 
p = parcellfun (8, @pinv, a); 
toc 
