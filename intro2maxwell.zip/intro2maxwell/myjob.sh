#!/bin/bash
#PBS -l walltime=00:20:00
#PBS -l pmem=1gb
#PBS -V

cd $PBS_O_WORKDIR


echo HOSTNAMES shown below
cat $PBS_NODEFILE 

echo -n Number of assigned cores = 
wc -l  $PBS_NODEFILE
