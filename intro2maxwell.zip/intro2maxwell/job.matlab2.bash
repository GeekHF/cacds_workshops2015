#!/bin/bash
#PBS -N matlabjob
#PBS -o matlabjob.o%j
#PBS -l nodes=1:ppn=4,pmem=1gb 
#PBS -S /bin/bash
#PBS -l walltime=00:05:00 
#PBS -M monkeybrain@uh.edu 

cd $PBS_O_WORKDIR


##set up your environment 
module add matlab


## run matlab program
matlab -nojvm < matrix_inversion100_matlab.m


