
#!/bin/bash 
cd $PBS_O_WORKDIR 
wc -l  < file${PBS_VNODENUM}.inp > ${PBS_VNODENUM}.out 

