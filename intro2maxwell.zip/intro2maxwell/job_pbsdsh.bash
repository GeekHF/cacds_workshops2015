#!/bin/bash
#PBS -l nodes=2:ppn=8,walltime=00:20:00
#PBS -N serial_tasks
#PBS -M jondoe@uh.edu
##PBS -m abe

pbsdsh -v $PBS_O_WORKDIR/subscript.bash 

