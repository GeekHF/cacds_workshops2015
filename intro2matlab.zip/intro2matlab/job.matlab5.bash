#!/bin/bash
#PBS -N matlabjob5
#PBS -o matlabjob5.o%j
#PBS -l nodes=1:ppn=1,pmem=1gb 
#PBS -S /bin/bash
#PBS -l walltime=00:05:00 
#PBS -M monkeybrain@uh.edu 

cd $PBS_O_WORKDIR


##set up your environment 
module add matlab


## run matlab program

./problem

