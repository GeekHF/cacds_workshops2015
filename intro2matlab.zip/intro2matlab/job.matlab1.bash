#!/bin/bash
#PBS -N matlabjob
#PBS -o matlabjob.o%j
#PBS -l nodes=1:ppn=1,pmem=1gb
#PBS -S /bin/bash
#PBS -l walltime=00:05:00

cd $PBS_O_WORKDIR


##set up your environment
module add matlab



date

matlab << EOF       
a = 10                                        
b = 20 
c = 30
d = sqrt((a + b + c)/pi)
exit 
EOF                                            

