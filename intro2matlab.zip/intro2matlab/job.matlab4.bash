#!/bin/bash
#PBS -N matlabjob4
#PBS -o matlabjob4.o%j
#PBS -l nodes=1:ppn=8,pmem=1gb
#PBS -S /bin/bash
#PBS -l walltime=00:05:00

cd $PBS_O_WORKDIR


##set up your environment
module add matlab



date

matlab << EOF       
c=[]
%Example, perform three large eigenvalue computations using three
 % workers or cores with Parallel Computing Toolbox software::
parpool(8)

tic; parfor i=1:3; c(:,i)=eig(rand(1000)); end; toc

tic; for i=1:3; c(:,i) = eig(rand(1000)); end; toc

exit 
EOF                                            

