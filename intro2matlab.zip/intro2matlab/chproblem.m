% Example 2.8 (Choleski decomposition)
A = [1.44 -0.36 5.52 0.00;
-0.36 10.33 -7.78 0.00;
5.52 -7.78 28.40 9.00;
0.00 0.00 9.00 61.00];
b = [0.04 -2.15 0 0.88];
L = choleski(A);
x = choleskiSol(L,b)
Check = A*x % Verify the result
