
from cmath import sqrt

def roots(a, b, c):
    if not ( isinstance(a,float) and isinstance(b,float) and isinstance(c,float) ):
        raise ValueError, 'Coefficients must be real.'
    A = -b / ( 2.0 * a ); 
    B = c / a  
    D = A**2 - B;
    s = sqrt(abs(D))
    if D > 0:
        if A >= 0:
            r1 = A + s; r2 = B / r1
        else:
            r2 = A - s; r1 = B / r2
    else:
        r1 = complex(A, s); r2 = complex(A, -s)
    return r1, r2
    
def test(a,b,c):
    x1, x2 = roots(a,b,c)
    print x1
    print x2
    
