/*
*	rules.cpp
*	this is a multi-line comment
*/
#include <iostream> 
 using	namespace std;
 int main()
{
	cout << "Braces come in pairs." ;
	cout << "Comments come in pairs." ;
	cout << "All statements end with semicolon." ; 
	cout << "Every program has a main function." ;
	return 0;
}

