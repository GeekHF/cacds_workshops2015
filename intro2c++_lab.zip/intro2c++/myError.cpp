#include < iostream > 
using namespace std;
int main()
{
  cuot <<"Find the error" << endl
  retrun 0;

}

