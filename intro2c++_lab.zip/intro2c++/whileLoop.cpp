#include  <iostream> 
using namespace std; 
int main()
{
  int counter,  value;
  value = 5;
  counter = 0;
  while ( counter < value)
  {
    counter++;
    cout <<  "counter  value is: " <<  counter <<  endl;
  }
  return  0;
}

