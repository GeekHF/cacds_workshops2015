
import pylab, random
import numpy as np
from mpi4py import MPI

dice = 200
trials = 150000

rank = MPI.COMM_WORLD.Get_rank()
size = MPI.COMM_WORLD.Get_size()
name = MPI.Get_processor_name()


random.seed(rank)


## Each process - one throwing of a number of a six-sided dice

values=np.zeros(trials/size)

for i in range(trials/size):
    sum = 0
    for j in range(dice):
        sum+=random.randint(1,6)
        values[i]=sum

data = np.array(MPI.COMM_WORLD.gather(values,root=0))

if rank == 0:
    data=data.flatten()
    mean=pylab.mean(data)
    std=pylab.std(data)
    print("Number of Trials=",trials, "times")
        print("Mean = ",mean)
        print("Standard deviation =",std)
        pylab.hist(data,20)
        pylab.xlabel('Value')
        pylab.ylabel('Number of times')
        pylab.savefig('multi_dice_mpi.png')
